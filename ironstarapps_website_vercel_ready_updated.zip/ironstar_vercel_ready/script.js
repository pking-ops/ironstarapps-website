const menuButton = document.querySelector('.menu-toggle');
const navLinks = document.querySelector('.nav-links');

if (menuButton && navLinks) {
  menuButton.addEventListener('click', () => {
    const isOpen = navLinks.classList.toggle('open');
    menuButton.setAttribute('aria-expanded', isOpen ? 'true' : 'false');
  });

  navLinks.querySelectorAll('a').forEach((link) => {
    link.addEventListener('click', () => {
      navLinks.classList.remove('open');
      menuButton.setAttribute('aria-expanded', 'false');
    });
  });
}


document.querySelectorAll('.call-link[data-phone]').forEach((link) => {
  const digits = link.getAttribute('data-phone');
  if (digits) link.setAttribute('href', `tel:${digits}`);
});

function handleIronStarForm(event) {
  event.preventDefault();
  const form = event.target;
  const honeypot = form.querySelector('input[name="website"]');
  if (honeypot && honeypot.value.trim() !== '') {
    return false;
  }
  alert('Thank you. Your request has been prepared. Connect this form to Squarespace form handling or your preferred email service to receive submissions.');
  return false;
}
